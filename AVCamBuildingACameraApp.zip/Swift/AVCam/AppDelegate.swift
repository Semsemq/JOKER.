/*
See the LICENSE.txt file for this sample’s licensing information.

Abstract:
The app's delegate object.
*/

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
}
