/*
See the LICENSE.txt file for this sample’s licensing information.

Abstract:
The app's delegate object.
*/

@import UIKit;

@interface AVCamAppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic) UIWindow *window;

@end
