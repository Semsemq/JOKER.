/*
See the LICENSE.txt file for this sample’s licensing information.

Abstract:
The app's primary view controller that presents the camera interface.
*/

@import UIKit;

@interface AVCamCameraViewController : UIViewController

@end
